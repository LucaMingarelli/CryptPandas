__about__ = ""
__version__= '0.0.1'
__author__ = 'Luca Mingarelli'
__email__ = "lucamingarelli@me.com"
__url__ = "...."


from cryptpandas.encrypt_decrypt import write_encrypted, read_encrypted
